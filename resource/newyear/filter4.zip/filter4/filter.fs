#ifdef GL_ES
    #ifdef GL_FRAGMENT_PRECISION_HIGH
    precision highp float;
    #else
    precision mediump float;
    #endif
#endif

varying vec2 textureCoordinate;
uniform sampler2D inputImageTexture;
uniform sampler2D inputImageTexture2;
uniform sampler2D inputImageTexture3;
uniform sampler2D inputImageTexture4;

uniform vec2 u_resolution;
uniform float u_time;

void main()
{
    vec2 uv = textureCoordinate;
    
    if (uv.x <= 0.5 && uv.y <= 0.5) {
        vec2 stickerUV = vec2(uv.x*2.0,uv.y * 2.0);
        gl_FragColor = texture2D(inputImageTexture,stickerUV);
    } else if(uv.x >= 0.5 && uv.y <= 0.5){
        vec2 stickerUV = vec2((uv.x - 0.5)*2.0,uv.y * 2.0);
        gl_FragColor = texture2D(inputImageTexture2,stickerUV);
    } else if(uv.x <= 0.5 && uv.y >= 0.5){
        vec2 stickerUV = vec2(uv.x * 2.0,(uv.y - 0.5)*2.0);
        gl_FragColor = texture2D(inputImageTexture3,stickerUV);
    }else if(uv.x >= 0.5 && uv.y >= 0.5){
        vec2 stickerUV = vec2((uv.x - 0.5)*2.0,(uv.y - 0.5)*2.0);
        gl_FragColor = texture2D(inputImageTexture4,stickerUV);
    }
}
